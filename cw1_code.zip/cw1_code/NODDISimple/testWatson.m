function testWatson()

n = [0,0,1];
mu= [1,0,0];

watson(0, n, mu)
watson(0.01, n, mu)
watson(0.1, n, mu)
watson(1, n, mu)

KummerComplex(1/2, 3/2, 0.01)^(-1)

end