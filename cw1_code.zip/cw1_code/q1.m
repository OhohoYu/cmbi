function q1()



[dwis, qhat, bvals] = q1Preprocessing(NR_IMAGES, W,H);

%q111(dwis, qhat, bvals);
%q112(dwis, qhat, bvals);
q113(dwis, qhat, bvals);
%q114(dwis, qhat, bvals);
%q116(dwis, qhat, bvals);
end










