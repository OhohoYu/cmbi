function y = q3ZeppTrans(x)
y(1) = x(1)^2;
y(2) = x(2)^2;
y(3) = q1Trans(x(3));
y(4) = x(4);
y(5) = x(5);
y(6) = x(6)^2;
y(7) = x(7)^2;

end