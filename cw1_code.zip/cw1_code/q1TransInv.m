function x = q1TransInv(y)
    x = -log(1/y - 1);
end