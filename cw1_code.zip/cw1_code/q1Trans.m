function y = q1Trans(x)
    y = 1/(1+exp(-x));
end